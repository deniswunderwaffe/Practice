create function orders_insert_trigger_fnc() returns trigger
    language plpgsql
as
$$
BEGIN



    INSERT INTO clients(name, phone, email)
    VALUES(NEW."name",NEW."phone",NEW."email");
    RETURN NEW;

END;

$$;

alter function orders_insert_trigger_fnc() owner to postgres;

